package tallerJueves_Semana2.src;

public class NotasCurso {
    public static void main(String[] args){

    /*    Ejercicio 3: Notas de un curso.
        Crea un programa que calcula la calificación promedio que se necesita
        obtener en las notas faltantes de un curso para aprobarlo,
        considerando la cantidad de calificaciones totales, las calificaciones ya
        obtenidas, el puntaje mínimo requerido para aprobar y la cantidad de
        notas faltantes. Importante: el total de notas del curso será de 8 notas,
        la calificación será de 0 a 100 y el promedio mínimo para aprobar el
        curso es de 76*/



    }
}
